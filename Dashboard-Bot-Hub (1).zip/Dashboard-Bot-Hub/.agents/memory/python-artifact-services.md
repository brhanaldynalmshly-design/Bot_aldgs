---
name: Python artifact service paths
description: Working-directory and uv-project behavior for Python services in this pnpm artifact workspace
---

For Python services declared in an artifact, make development paths relative to the artifact directory and production paths relative to the workspace root. Dependency-only uv projects should set `package = false` when they are not building an installable Python package.

**Why:** The development workflow starts in the artifact directory, while production run arguments resolve from the workspace root. An implicit uv package build can also fail when the generated package directory does not match the project name.

**How to apply:** Use explicit `uv --project` and ASGI `--app-dir` values for each environment. Confirm the managed development workflow starts successfully before relying on production-relative paths.
