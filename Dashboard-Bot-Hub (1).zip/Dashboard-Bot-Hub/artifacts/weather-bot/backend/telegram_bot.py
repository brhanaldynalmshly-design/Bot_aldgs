from __future__ import annotations

import asyncio
import os
import re
from datetime import date, timedelta
from typing import Any

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from database import write_log
from weather import (
    WeatherInputError,
    WeatherProviderError,
    execute_weather_request,
    resolve_local_today,
    resolve_location_name,
)

telegram_status = "starting"
_application: Application | None = None
FROST_TEMPERATURE_THRESHOLD_C = 2.0
FROST_DEW_POINT_THRESHOLD_C = 0.0
FROST_WARNING_HTML = (
    "<b>⚠️ تنبيه: احتمالية عالية لحدوث صقيع في هذه الساعة! "
    "يرجى أخذ الاحتياطات للمزروعات.</b>"
)
DAWN_FROST_WARNING_HTML = (
    "<b>🚨 تحذير صقيع الفجر المباشر: تم رصد مؤشرات صقيع عالية جداً "
    "بين الساعة 5 و 6 صباحاً! يرجى حماية النباتات والمزروعات فوراً.</b>"
)
DETAIL_SEPARATOR = "────────────"


def get_telegram_status() -> str:
    return telegram_status


def _location_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [[KeyboardButton("ارسل موقعك الحالي 📍", request_location=True)]],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


def _period_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[
            InlineKeyboardButton("☀️ طقس اليوم", callback_data="weather:period:today"),
            InlineKeyboardButton("🔮 طقس الغد", callback_data="weather:period:tomorrow"),
        ]]
    )


def _time_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "🔬 فحص صقيع الفجر 5-6 صباحاً",
                    callback_data="weather:time:dawn",
                )
            ],
            [
                InlineKeyboardButton(
                    "🕒 الظهر 12:00 م",
                    callback_data="weather:time:noon",
                ),
                InlineKeyboardButton(
                    "🕗 المساء 08:00 م",
                    callback_data="weather:time:evening",
                ),
            ],
            [
                InlineKeyboardButton(
                    "📊 تقرير اليوم كاملاً",
                    callback_data="weather:time:day",
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ العودة للفترات",
                    callback_data="weather:back:periods",
                )
            ],
        ]
    )


def _back_to_time_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("↩️ العودة للخلف", callback_data="weather:back:times")]]
    )


def _parse_values(values: list[str]) -> tuple[float, float, str] | None:
    if len(values) == 1:
        values = re.split(r"[\s,;]+", values[0].strip())
    if len(values) != 3:
        return None
    try:
        latitude = float(values[0])
        longitude = float(values[1])
    except ValueError:
        return None
    if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
        return None
    return latitude, longitude, values[2]


def _is_period(value: str) -> bool:
    return bool(re.fullmatch(r"(?:\d{4}|\d{4}-\d{2}-\d{2})", value.strip()))


async def _start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message:
        await message.reply_text(
            "🌦️ أهلًا بك في بوت الطقس العالمي!\n\n"
            "📍 أرسل موقعك الحالي من الزر أدناه، ثم اختر طقس اليوم أو الغد "
            "وحدد الفحص الذي تريده.\n"
            "🔎 أو اكتب اسم منطقتك أو مديريتك أو عزلتك للبحث عنها.\n"
            "🔬 يتضمن التقرير فحص مؤشرات صقيع الفجر بين الخامسة والسادسة صباحًا.\n\n"
            "💡 يمكنك أيضًا إرسال الإحداثيات والتاريخ مباشرة عبر /weather.",
            reply_markup=_location_keyboard(),
        )


async def _help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message:
        await message.reply_text(
            "📖 طريقة الاستخدام\n\n"
            "1️⃣ اضغط «ارسل موقعك الحالي 📍» لإرسال إحداثياتك.\n"
            "أو اكتب اسم المنطقة أو المديرية أو العزلة.\n"
            "2️⃣ اختر طقس اليوم أو الغد من الأزرار.\n"
            "3️⃣ اختر فحص الفجر، الظهر، المساء، أو تقرير اليوم كاملًا.\n"
            "↩️ استخدم زر العودة للرجوع إلى قائمة الفحوصات دون إعادة إرسال الموقع.\n\n"
            "⌨️ أو أرسل الأمر كاملًا:\n"
            "/weather 40.7128 -74.0060 2025-06-18\n"
            "/weather 40.7128 -74.0060 2025\n\n"
            "🌡️ التقارير تعرض الحرارة الصغرى والكبرى، ومتوسط الحرارة "
            "والرطوبة ونقطة التكثف، مع تفاصيل الطقس ساعة بساعة.",
            reply_markup=_location_keyboard(),
        )


async def _location_received(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    message = update.effective_message
    if message is None or message.location is None:
        return
    latitude = message.location.latitude
    longitude = message.location.longitude
    try:
        local_today = await resolve_local_today(latitude, longitude)
    except WeatherProviderError:
        await write_log(
            "warning",
            "telegram",
            "Could not resolve the local date for a shared Telegram location.",
        )
        await message.reply_text(
            "⚠️ تعذر تحديد التاريخ المحلي لهذا الموقع الآن. حاول مجددًا أو "
            "استخدم الأمر /weather مع الإحداثيات والتاريخ.",
            reply_markup=_location_keyboard(),
        )
        return

    await _show_period_choices(
        message,
        context,
        latitude,
        longitude,
        local_today,
    )


async def _show_period_choices(
    message: Any,
    context: ContextTypes.DEFAULT_TYPE,
    latitude: float,
    longitude: float,
    local_today: date,
    location_name: str | None = None,
) -> None:
    context.user_data["weather_location"] = (latitude, longitude)
    context.user_data["weather_today"] = local_today.isoformat()
    context.user_data.pop("weather_selected_date", None)
    if location_name:
        context.user_data["weather_location_name"] = location_name
        location_text = f"✅ تم تحديد الموقع: {location_name}"
    else:
        context.user_data.pop("weather_location_name", None)
        location_text = "✅ تم استلام موقعك الحالي"
    await message.reply_text(
        f"{location_text}\n"
        f"📍 الإحداثيات: {latitude:.4f}، {longitude:.4f}\n"
        f"📅 التاريخ المحلي الآن: {local_today.isoformat()}\n\n"
        "اختر الفترة التي تريدها:",
        reply_markup=_period_keyboard(),
    )


async def _resolve_text_location(
    message: Any,
    context: ContextTypes.DEFAULT_TYPE,
    location_query: str,
) -> None:
    try:
        latitude, longitude, resolved_name, local_today = await resolve_location_name(
            location_query
        )
    except WeatherInputError:
        await message.reply_text(
            "⚠️ لم أتعرف على هذا المكان. أرسل اسم المنطقة أو المديرية أو العزلة "
            "بشكل أوضح، أو شارك موقعك الحالي."
        )
        return
    except WeatherProviderError:
        await message.reply_text(
            "⚠️ تعذر البحث عن الموقع الآن. حاول مرة أخرى أو شارك موقعك الحالي."
        )
        return

    await _show_period_choices(
        message,
        context,
        latitude,
        longitude,
        local_today,
        location_name=resolved_name,
    )


async def _inline_weather_selection(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    query = update.callback_query
    if query is None:
        return
    await query.answer()
    message = query.message
    if message is None:
        return

    callback_data = query.data or ""
    if callback_data == "weather:back:times":
        selected_date = context.user_data.get("weather_selected_date")
        location = context.user_data.get("weather_location")
        if not location or not selected_date:
            await query.edit_message_text(
                "⚠️ انتهت صلاحية الاختيار. شارك موقعك أو اكتب اسم المكان من جديد."
            )
            return
        await query.edit_message_text(
            f"📅 التاريخ المختار: {selected_date}\nاختر نوع الفحص:",
            reply_markup=_time_keyboard(),
        )
        return

    if callback_data == "weather:back:periods":
        location = context.user_data.get("weather_location")
        if not location:
            await query.edit_message_text(
                "⚠️ انتهت صلاحية الموقع. شارك موقعك أو اكتب اسم المكان من جديد."
            )
            return
        today_value = context.user_data.get("weather_today")
        if not today_value:
            try:
                local_today = await resolve_local_today(location[0], location[1])
            except WeatherProviderError:
                await query.edit_message_text(
                    "⚠️ تعذر تحديد التاريخ المحلي. حاول العودة إلى قائمة الفترات مجددًا."
                )
                return
            today_value = local_today.isoformat()
            context.user_data["weather_today"] = today_value
        await query.edit_message_text(
            f"📅 التاريخ المحلي الآن: {today_value}\nاختر الفترة التي تريدها:",
            reply_markup=_period_keyboard(),
        )
        return

    if callback_data in ("weather:period:today", "weather:period:tomorrow"):
        today_value = context.user_data.get("weather_today")
        if not today_value:
            await query.edit_message_text(
                "⚠️ انتهت صلاحية الموقع. شارك موقعك أو اكتب اسم المكان من جديد."
            )
            return
        try:
            local_today = date.fromisoformat(today_value)
        except (TypeError, ValueError):
            await query.edit_message_text(
                "⚠️ تعذر قراءة التاريخ المحلي. شارك موقعك أو اكتب اسم المكان من جديد."
            )
            return

        offset = 1 if callback_data.endswith("tomorrow") else 0
        selected_date = local_today + timedelta(days=offset)
        context.user_data["weather_selected_date"] = selected_date.isoformat()
        await query.edit_message_text(
            f"📅 التاريخ المحلي المختار: {selected_date.isoformat()}\n"
            "اختر نوع الفحص:",
            reply_markup=_time_keyboard(),
        )
        return

    time_selection = {
        "weather:time:dawn": "dawn",
        "weather:time:noon": "noon",
        "weather:time:evening": "evening",
        "weather:time:day": "day",
    }.get(callback_data)
    location = context.user_data.get("weather_location")
    selected_date = context.user_data.get("weather_selected_date")
    if time_selection is None:
        return
    if not location or not selected_date:
        await query.edit_message_text(
            "⚠️ انتهت صلاحية الاختيار. شارك موقعك أو اكتب اسم المكان من جديد."
        )
        return

    await query.edit_message_text("⏳ جارٍ جلب بيانات الطقس للساعات المطلوبة...")
    try:
        result = await execute_weather_request(
            location[0],
            location[1],
            selected_date,
            user_name="Telegram",
        )
    except (WeatherInputError, WeatherProviderError):
        await query.edit_message_text(
            "⚠️ تعذر جلب بيانات الطقس لهذه الفترة. اختر يومًا آخر أو حاول مجددًا."
        )
        return
    except Exception:
        await write_log(
            "error",
            "telegram",
            "An inline Telegram weather lookup failed unexpectedly.",
        )
        await query.edit_message_text(
            "⚠️ حدث خطأ غير متوقع أثناء جلب الطقس. حاول مرة أخرى لاحقًا."
        )
        return

    responses = _build_time_selection_messages(
        result,
        location[0],
        location[1],
        selected_date,
        time_selection,
    )
    for index, response in enumerate(responses):
        reply_kwargs: dict[str, Any] = {"parse_mode": ParseMode.HTML}
        if index == len(responses) - 1:
            reply_kwargs["reply_markup"] = _back_to_time_keyboard()
        await message.reply_text(response, **reply_kwargs)


async def _weather(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    message = update.effective_message
    if message is None:
        return
    parsed = _parse_values(list(context.args))
    if parsed is not None:
        await _send_weather(message, parsed, context)
        return

    saved_location = context.user_data.get("weather_location")
    if saved_location and len(context.args) == 1 and _is_period(context.args[0]):
        await _send_weather(
            message,
            (saved_location[0], saved_location[1], context.args[0]),
            context,
        )
        return

    if not context.args:
        await message.reply_text(
            "📍 أرسل موقعك أو اكتب اسم منطقتك، ثم أرسل التاريخ أو السنة.\n"
            "أو استخدم: /weather خط_العرض خط_الطول YYYY-MM-DD",
            reply_markup=_location_keyboard(),
        )
        return
    await message.reply_text(
        "⚠️ صيغة الأمر غير صحيحة.\n"
        "استخدم: /weather خط_العرض خط_الطول YYYY-MM-DD\n"
        "أو: /weather خط_العرض خط_الطول YYYY"
        )


async def _plain_text(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    message = update.effective_message
    if message is None or not message.text:
        return
    parsed = _parse_values([message.text])
    if parsed is not None:
        await _send_weather(message, parsed, context)
        return

    saved_location = context.user_data.get("weather_location")
    value = message.text.strip()
    if saved_location:
        if _is_period(value):
            await _send_weather(
                message,
                (saved_location[0], saved_location[1], value),
                context,
            )
        else:
            await _resolve_text_location(message, context, value)
        return

    if _is_period(value):
        await message.reply_text(
            "📍 أرسل موقعك الحالي أو اكتب اسم المنطقة أو المديرية أو العزلة أولًا.",
            reply_markup=_location_keyboard(),
        )
        return
    await _resolve_text_location(message, context, value)


def _display_number(value: Any) -> str:
    if not isinstance(value, (int, float)):
        return "غير متوفر"
    return f"{value:.1f}"


def _hourly_frost_risk(hour: dict[str, Any]) -> bool:
    temperature = hour.get("temperature")
    dew_point = hour.get("dewPoint")
    return (
        isinstance(temperature, (int, float))
        and isinstance(dew_point, (int, float))
        and temperature <= FROST_TEMPERATURE_THRESHOLD_C
        and dew_point < FROST_DEW_POINT_THRESHOLD_C
    )


def _reading_frost_risk(reading: dict[str, Any]) -> bool:
    hours = reading.get("hours", [])
    if isinstance(hours, list) and hours:
        return any(
            _hourly_frost_risk(hour)
            for hour in hours
            if isinstance(hour, dict)
        )

    daily_low = reading.get("minTemperature")
    dew_point = reading.get("dewPoint")
    return (
        isinstance(daily_low, (int, float))
        and isinstance(dew_point, (int, float))
        and daily_low <= FROST_TEMPERATURE_THRESHOLD_C
        and dew_point < FROST_DEW_POINT_THRESHOLD_C
    )


def _dawn_frost_risk(hour: dict[str, Any]) -> bool:
    temperature = hour.get("temperature")
    dew_point = hour.get("dewPoint")
    return (
        isinstance(temperature, (int, float))
        and isinstance(dew_point, (int, float))
        and temperature <= 3.0
        and dew_point <= 0.0
    )


def _hour_details_line(hour: dict[str, Any], time_label: str | None = None) -> str:
    return "\n".join(
        [
            f"⏰ {time_label or hour.get('time', '—')}",
            f"🌡️ الحرارة: {_display_number(hour.get('temperature'))}°م",
            f"💧 الرطوبة: {_display_number(hour.get('humidity'))}%",
            f"🌫️ نقطة التكثف: {_display_number(hour.get('dewPoint'))}°م",
            f"💨 سرعة الرياح: {_display_number(hour.get('windSpeed'))} كم/س",
        ]
    )


def _build_dawn_section(reading: dict[str, Any]) -> list[str]:
    hourly = reading.get("hours", [])
    by_time = {
        str(hour.get("time", "")).strip().upper(): hour
        for hour in hourly
        if isinstance(hour, dict)
    } if isinstance(hourly, list) else {}
    lines = ["🔬 فحص مؤشرات الصقيع (الفجر 5 - 6 صباحاً)"]
    urgent_risk = False
    for index, time_label in enumerate(("05:00 AM", "06:00 AM")):
        if index:
            lines.append(DETAIL_SEPARATOR)
        hour = by_time.get(time_label)
        if hour is None:
            hour = {
                "temperature": None,
                "humidity": None,
                "dewPoint": None,
                "windSpeed": None,
            }
        lines.append(_hour_details_line(hour, time_label))
        if _dawn_frost_risk(hour):
            urgent_risk = True
    if urgent_risk:
        lines.append(DAWN_FROST_WARNING_HTML)
    return lines


def _arabic_conditions(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return "غير متوفر"
    condition = value.casefold()
    translations = [
        ("freezing rain", "مطر متجمد"),
        ("thunderstorm", "عواصف رعدية"),
        ("snow", "ثلوج"),
        ("rain", "ممطر"),
        ("partially cloudy", "غائم جزئيًا"),
        ("overcast", "غائم"),
        ("clear", "سماء صافية"),
        ("fog", "ضباب"),
        ("mist", "ضباب خفيف"),
        ("wind", "رياح"),
        ("ice", "جليد"),
    ]
    labels = [arabic for keyword, arabic in translations if keyword in condition]
    return "، ".join(dict.fromkeys(labels)) if labels else "حالة الطقس متغيرة"


def _chunk_lines(lines: list[str], limit: int = 3500) -> list[str]:
    messages: list[str] = []
    current: list[str] = []
    current_length = 0
    for line in lines:
        extra_length = len(line) + (1 if current else 0)
        if current and current_length + extra_length > limit:
            messages.append("\n".join(current))
            current = []
            current_length = 0
        current.append(line)
        current_length += len(line) + (1 if len(current) > 1 else 0)
    if current:
        messages.append("\n".join(current))
    return messages


def _build_weather_messages(
    result: dict[str, Any],
    latitude: float,
    longitude: float,
    date_or_year: str,
) -> list[str]:
    request = result["request"]
    readings = result["readings"]
    source_labels = {
        "forecast": "توقعات جوية",
        "historical": "سجلات تاريخية",
        "mixed": "سجلات تاريخية وتوقعات متاحة",
    }
    source_label = source_labels.get(request.get("source"), "بيانات الطقس")

    daily_lows = [
        reading["minTemperature"]
        for reading in readings
        if isinstance(reading.get("minTemperature"), (int, float))
    ]
    daily_highs = [
        reading["maxTemperature"]
        for reading in readings
        if isinstance(reading.get("maxTemperature"), (int, float))
    ]
    summary = [
        "🌦️ تقرير الطقس",
        f"📍 الموقع: {latitude:.4f}، {longitude:.4f}",
        f"📅 الفترة: {date_or_year}",
        f"🧭 المصدر: {source_label}",
        f"🌡️ متوسط الحرارة: {_display_number(request.get('temperature'))}°م",
        f"⬇️ الحرارة الصغرى: {_display_number(min(daily_lows) if daily_lows else None)}°م",
        f"⬆️ الحرارة الكبرى: {_display_number(max(daily_highs) if daily_highs else None)}°م",
        f"💧 متوسط الرطوبة: {_display_number(request.get('humidity'))}%",
        f"🌫️ نقطة التكثف: {_display_number(request.get('dewPoint'))}°م",
        f"☁️ الحالة: {_arabic_conditions(request.get('conditions'))}",
    ]

    reading = readings[0] if readings else {}
    if request.get("requestType") != "year":
        if _reading_frost_risk(reading):
            summary.append(FROST_WARNING_HTML)
        summary.extend(_build_dawn_section(reading))

    if result.get("periodNote"):
        last_date = readings[-1].get("date", "") if readings else ""
        if request.get("source") == "mixed":
            summary.append(
                f"📌 يتضمن النطاق بيانات تاريخية وتوقعات متاحة حتى {last_date}."
            )
        else:
            summary.append(f"📌 التوقعات المتاحة حتى {last_date}.")

    messages = _chunk_lines(summary)
    if request.get("requestType") == "year":
        daily_lines = ["📆 الملخص اليومي — الصغرى والكبرى لكل يوم"]
        for index, reading in enumerate(readings):
            if index:
                daily_lines.append(DETAIL_SEPARATOR)
            daily_lines.append(
                "\n".join(
                    [
                        f"🗓️ {reading.get('date', '—')}",
                        f"🌡️ متوسط الحرارة: {_display_number(reading.get('temperature'))}°م",
                        f"⬇️ الحرارة الصغرى: {_display_number(reading.get('minTemperature'))}°م",
                        f"⬆️ الحرارة الكبرى: {_display_number(reading.get('maxTemperature'))}°م",
                        f"💧 الرطوبة: {_display_number(reading.get('humidity'))}%",
                        f"🌫️ نقطة التكثف: {_display_number(reading.get('dewPoint'))}°م",
                        f"☁️ الحالة: {_arabic_conditions(reading.get('conditions'))}",
                    ]
                )
            )
            if _reading_frost_risk(reading):
                daily_lines.append(FROST_WARNING_HTML)
        messages.extend(_chunk_lines(daily_lines))
        return messages

    hourly = reading.get("hours", [])
    hourly_lines = ["🕒 تفاصيل الطقس ساعة بساعة"]
    for index, hour in enumerate(hourly):
        if index:
            hourly_lines.append(DETAIL_SEPARATOR)
        hourly_lines.append(_hour_details_line(hour))
        hour_label = str(hour.get("time", "")).strip().upper()
        if _dawn_frost_risk(hour) and hour_label in ("05:00 AM", "06:00 AM"):
            hourly_lines.append("🚨 مؤشرات صقيع لهذه الساعة — راجع فحص الفجر أعلاه.")
        elif _hourly_frost_risk(hour):
            hourly_lines.append(FROST_WARNING_HTML)
    if not hourly:
        hourly_lines.append("لا تتوفر بيانات ساعية لهذا اليوم.")
    messages.extend(_chunk_lines(hourly_lines))
    return messages


def _find_hour(reading: dict[str, Any], time_label: str) -> dict[str, Any] | None:
    for hour in reading.get("hours", []):
        if (
            isinstance(hour, dict)
            and str(hour.get("time", "")).strip().upper() == time_label
        ):
            return hour
    return None


def _build_time_selection_messages(
    result: dict[str, Any],
    latitude: float,
    longitude: float,
    selected_date: str,
    selection: str,
) -> list[str]:
    if selection == "day":
        return _build_weather_messages(
            result,
            latitude,
            longitude,
            selected_date,
        )

    reading = result["readings"][0] if result.get("readings") else {}
    if selection == "dawn":
        lines = [
            f"🌦️ تقرير فحص الفجر — {selected_date}",
            f"📍 الموقع: {latitude:.4f}، {longitude:.4f}",
            *_build_dawn_section(reading),
        ]
        return _chunk_lines(lines)

    selected_hours = {
        "noon": ("12:00 PM", "🕒 تقرير الظهر"),
        "evening": ("08:00 PM", "🕗 تقرير المساء"),
    }
    if selection not in selected_hours:
        return ["⚠️ خيار الفحص غير معروف. أرسل /start لبدء الاختيار من جديد."]

    time_label, title = selected_hours[selection]
    hour = _find_hour(reading, time_label) or {
        "temperature": None,
        "humidity": None,
        "dewPoint": None,
        "windSpeed": None,
    }
    lines = [
        f"{title} — {selected_date}",
        f"📍 الموقع: {latitude:.4f}، {longitude:.4f}",
        _hour_details_line(hour, time_label),
    ]
    if _hourly_frost_risk(hour):
        lines.append(FROST_WARNING_HTML)
    return _chunk_lines(lines)


async def _send_weather(
    message: Any,
    parsed: tuple[float, float, str],
    context: ContextTypes.DEFAULT_TYPE | None = None,
) -> None:
    latitude, longitude, date_or_year = parsed
    try:
        result = await execute_weather_request(
            latitude,
            longitude,
            date_or_year,
            user_name="Telegram",
        )
    except WeatherInputError as error:
        await write_log("warning", "telegram", "A Telegram weather request had invalid dates.")
        error_text = str(error)
        if "1900" in error_text:
            arabic_error = "⚠️ أدخل سنة بين 1900 و2200."
        elif "next" in error_text or "limited" in error_text:
            arabic_error = "⚠️ التوقعات متاحة للأيام الأربعة عشر القادمة فقط. اختر تاريخًا أقرب أو فترة تاريخية مكتملة."
        else:
            arabic_error = "⚠️ التاريخ غير صالح. أرسل تاريخًا بصيغة YYYY-MM-DD أو سنة من أربعة أرقام."
        await message.reply_text(arabic_error)
        return
    except WeatherProviderError:
        await message.reply_text(
            "⚠️ تعذر جلب بيانات الطقس الآن. حاول مرة أخرى بعد قليل."
        )
        return
    except Exception:
        await write_log("error", "telegram", "An unexpected Telegram weather request error occurred.")
        await message.reply_text("⚠️ حدث خطأ غير متوقع. حاول مرة أخرى لاحقًا.")
        return

    responses = _build_weather_messages(
        result,
        latitude,
        longitude,
        date_or_year,
    )
    has_daily_date = bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_or_year))
    if context is not None:
        context.user_data["weather_location"] = (latitude, longitude)
        if has_daily_date:
            context.user_data["weather_selected_date"] = date_or_year
    for index, response in enumerate(responses):
        reply_kwargs: dict[str, Any] = {"parse_mode": ParseMode.HTML}
        if has_daily_date and context is not None and index == len(responses) - 1:
            reply_kwargs["reply_markup"] = _back_to_time_keyboard()
        await message.reply_text(response, **reply_kwargs)


async def run_telegram_bot() -> None:
    global telegram_status, _application

    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        telegram_status = "not_configured"
        await write_log("warning", "telegram", "Telegram bot token is not configured.")
        await asyncio.Event().wait()
        return

    telegram_status = "connecting"
    application = Application.builder().token(token).build()
    application.add_handler(CommandHandler("start", _start))
    application.add_handler(CommandHandler("help", _help))
    application.add_handler(CommandHandler("weather", _weather))
    application.add_handler(
        CallbackQueryHandler(
            _inline_weather_selection,
            pattern=r"^weather:(period|time|back):",
        )
    )
    application.add_handler(MessageHandler(filters.LOCATION, _location_received))
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, _plain_text)
    )
    _application = application

    try:
        await application.initialize()
        await application.start()
        if application.updater is None:
            raise RuntimeError("Telegram polling updater is unavailable.")
        await application.updater.start_polling(drop_pending_updates=True)
        telegram_status = "running"
        await write_log("info", "telegram", "Telegram bot polling started.")
        await asyncio.Event().wait()
    except asyncio.CancelledError:
        raise
    except Exception:
        telegram_status = "error"
        await write_log(
            "error",
            "telegram",
            "Telegram bot could not start. Check the bot token and Telegram connectivity.",
        )
    finally:
        if application.updater and application.updater.running:
            await application.updater.stop()
        if application.running:
            await application.stop()
        await application.shutdown()
        _application = None
        if telegram_status == "running":
            telegram_status = "stopped"
