from __future__ import annotations

import os
import re
import time
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from typing import Any
from urllib.parse import quote

import httpx

from database import record_request, write_log

VISUAL_CROSSING_URL = (
    "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline"
)
MAX_FORECAST_DAYS = 14


class WeatherInputError(ValueError):
    pass


class WeatherProviderError(RuntimeError):
    pass


async def resolve_local_today(latitude: float, longitude: float) -> date:
    api_key = os.getenv("VISUAL_CROSSING_API_KEY")
    if not api_key:
        raise WeatherProviderError("Visual Crossing API key is not configured.")

    location = f"{latitude:.6f},{longitude:.6f}"
    url = f"{VISUAL_CROSSING_URL}/{location}/today"
    params = {
        "unitGroup": "metric",
        "include": "days",
        "key": api_key,
        "contentType": "json",
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(url, params=params)
        if response.status_code >= 400:
            raise WeatherProviderError(
                f"Visual Crossing returned HTTP {response.status_code}."
            )
        payload = response.json()
        provider_days = payload.get("days", [])
        if not isinstance(provider_days, list) or not provider_days:
            raise WeatherProviderError(
                "Visual Crossing returned no date for the requested location."
            )
        local_date = provider_days[0].get("datetime")
        if not isinstance(local_date, str):
            raise WeatherProviderError(
                "Visual Crossing returned an invalid local date."
            )
        return date.fromisoformat(local_date)
    except WeatherProviderError:
        raise
    except (httpx.HTTPError, ValueError, TypeError, AttributeError):
        raise WeatherProviderError(
            "Could not resolve the current local date for this location."
        ) from None


async def resolve_location_name(
    location_name: str,
) -> tuple[float, float, str, date]:
    normalized_name = " ".join(location_name.split())
    if not normalized_name:
        raise WeatherInputError("Enter a region, district, or village name.")
    if len(normalized_name) > 120:
        raise WeatherInputError("Location names must be 120 characters or fewer.")

    api_key = os.getenv("VISUAL_CROSSING_API_KEY")
    if not api_key:
        raise WeatherProviderError("Visual Crossing API key is not configured.")

    encoded_location = quote(normalized_name, safe="")
    url = f"{VISUAL_CROSSING_URL}/{encoded_location}/today"
    params = {
        "unitGroup": "metric",
        "include": "days",
        "key": api_key,
        "contentType": "json",
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(url, params=params)
        if response.status_code in (400, 404):
            raise WeatherInputError("The requested location could not be found.")
        if response.status_code >= 400:
            raise WeatherProviderError(
                f"Visual Crossing returned HTTP {response.status_code}."
            )

        payload = response.json()
        if not isinstance(payload, dict):
            raise WeatherProviderError("Visual Crossing returned an invalid location.")
        latitude = payload.get("latitude")
        longitude = payload.get("longitude")
        days = payload.get("days", [])
        local_date = days[0].get("datetime") if isinstance(days, list) and days else None
        if (
            not isinstance(latitude, (int, float))
            or not isinstance(longitude, (int, float))
            or not -90 <= latitude <= 90
            or not -180 <= longitude <= 180
            or not isinstance(local_date, str)
        ):
            raise WeatherInputError("The requested location could not be resolved.")
        try:
            resolved_date = date.fromisoformat(local_date)
        except ValueError:
            raise WeatherProviderError(
                "Visual Crossing returned an invalid local date."
            ) from None

        resolved_name = payload.get("resolvedAddress")
        if not isinstance(resolved_name, str) or not resolved_name.strip():
            resolved_name = normalized_name
        return float(latitude), float(longitude), resolved_name.strip(), resolved_date
    except (WeatherInputError, WeatherProviderError):
        raise
    except (httpx.HTTPError, ValueError, TypeError, AttributeError, IndexError):
        raise WeatherProviderError(
            "Could not resolve the requested location."
        ) from None


def parse_period(value: str) -> tuple[date, date, str, str, str | None]:
    raw = value.strip()
    if re.fullmatch(r"\d{4}", raw):
        year = int(raw)
        if year < 1900 or year > 2200:
            raise WeatherInputError("Enter a year from 1900 through 2200.")
        start = date(year, 1, 1)
        requested_end = date(year, 12, 31)
        request_type = "year"
    elif re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
        try:
            start = date.fromisoformat(raw)
        except ValueError as error:
            raise WeatherInputError("Enter a valid date in YYYY-MM-DD format.") from error
        requested_end = start
        request_type = "date"
    else:
        raise WeatherInputError("Use a date in YYYY-MM-DD format or a four-digit year.")

    today = datetime.now(timezone.utc).date()
    forecast_limit = today + timedelta(days=MAX_FORECAST_DAYS)
    if start > forecast_limit:
        raise WeatherInputError(
            f"Visual Crossing forecasts are limited to the next {MAX_FORECAST_DAYS} days. "
            "Choose a nearer date or a completed historical period."
        )

    effective_end = min(requested_end, forecast_limit)
    if requested_end < today:
        source = "historical"
        period_note = None
    elif start < today:
        source = "mixed"
        period_note = (
            f"This period combines historical observations and forecast data through "
            f"{effective_end.isoformat()}."
            if effective_end < requested_end
            else "This period combines historical observations and available forecast data."
        )
    else:
        source = "forecast"
        period_note = (
            f"Forecast data is available through {effective_end.isoformat()}."
            if effective_end < requested_end
            else None
        )

    return start, effective_end, request_type, source, period_note


def _average(days: list[dict[str, Any]], key: str) -> float | None:
    values: list[float] = []
    for day in days:
        value = day.get(key)
        if isinstance(value, (int, float)):
            values.append(float(value))
    if not values:
        return None
    return round(sum(values) / len(values), 1)


def _conditions(days: list[dict[str, Any]]) -> str | None:
    values = [
        str(day["conditions"]).strip()
        for day in days
        if day.get("conditions") and str(day["conditions"]).strip()
    ]
    if not values:
        return None
    return Counter(values).most_common(1)[0][0]


def _format_hour(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    raw = value.strip()
    for pattern in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.strptime(raw, pattern).strftime("%I:%M %p")
        except ValueError:
            continue
    return None


def _map_provider_days(
    provider_days: list[dict[str, Any]],
    *,
    include_hours: bool,
) -> list[dict[str, Any]]:
    readings: list[dict[str, Any]] = []
    for day in provider_days:
        if not isinstance(day, dict):
            continue
        hours: list[dict[str, Any]] = []
        provider_hours = day.get("hours", [])
        if include_hours and isinstance(provider_hours, list):
            for hour in provider_hours:
                if not isinstance(hour, dict):
                    continue
                time_label = _format_hour(hour.get("datetime"))
                if time_label is None:
                    continue
                hours.append(
                    {
                        "time": time_label,
                        "temperature": hour.get("temp"),
                        "humidity": hour.get("humidity"),
                        "dewPoint": hour.get("dew"),
                        "windSpeed": hour.get("windspeed"),
                    }
                )
        readings.append(
            {
                "date": str(day.get("datetime", "")),
                "temperature": day.get("temp"),
                "minTemperature": day.get("tempmin"),
                "maxTemperature": day.get("tempmax"),
                "humidity": day.get("humidity"),
                "dewPoint": day.get("dew"),
                "conditions": day.get("conditions"),
                "hours": hours,
            }
        )
    return readings


async def execute_weather_request(
    latitude: float,
    longitude: float,
    date_or_year: str,
    *,
    user_name: str,
) -> dict[str, Any]:
    start, end, request_type, source, period_note = parse_period(date_or_year)
    api_key = os.getenv("VISUAL_CROSSING_API_KEY")
    if not api_key:
        raise WeatherProviderError("Visual Crossing API key is not configured.")

    started = time.perf_counter()
    location = f"{latitude:.6f},{longitude:.6f}"
    url = f"{VISUAL_CROSSING_URL}/{location}/{start.isoformat()}/{end.isoformat()}"
    params = {
        "unitGroup": "metric",
        "include": "days,hours" if request_type == "date" else "days",
        "key": api_key,
        "contentType": "json",
    }

    try:
        async with httpx.AsyncClient(timeout=35) as client:
            response = await client.get(url, params=params)
        if response.status_code >= 400:
            raise WeatherProviderError(
                f"Visual Crossing returned HTTP {response.status_code}."
            )
        payload = response.json()
        provider_days = payload.get("days", [])
        if not isinstance(provider_days, list) or not provider_days:
            raise WeatherProviderError("Visual Crossing returned no daily weather data.")
    except WeatherProviderError:
        response_ms = int((time.perf_counter() - started) * 1000)
        await record_request(
            latitude=latitude,
            longitude=longitude,
            requested_date=date_or_year,
            request_type=request_type,
            status="error",
            source=source,
            response_ms=response_ms,
            user_name=user_name,
        )
        await write_log("error", "weather", "Weather provider request failed.")
        raise
    except (httpx.HTTPError, ValueError, TypeError):
        response_ms = int((time.perf_counter() - started) * 1000)
        await record_request(
            latitude=latitude,
            longitude=longitude,
            requested_date=date_or_year,
            request_type=request_type,
            status="error",
            source=source,
            response_ms=response_ms,
            user_name=user_name,
        )
        await write_log("error", "weather", "Could not read a response from Visual Crossing.")
        raise WeatherProviderError(
            "Could not read a valid weather response. Try again shortly."
        ) from None

    readings = _map_provider_days(
        provider_days,
        include_hours=request_type == "date",
    )
    if not readings:
        raise WeatherProviderError("Visual Crossing returned no usable daily readings.")

    response_ms = int((time.perf_counter() - started) * 1000)
    request = await record_request(
        latitude=latitude,
        longitude=longitude,
        requested_date=date_or_year,
        request_type=request_type,
        status="success",
        source=source,
        response_ms=response_ms,
        user_name=user_name,
        temperature=_average(provider_days, "temp"),
        humidity=_average(provider_days, "humidity"),
        dew_point=_average(provider_days, "dew"),
        conditions=_conditions(provider_days),
    )
    await write_log(
        "info",
        "weather",
        f"Weather request completed for {latitude:.4f}, {longitude:.4f} ({date_or_year}).",
    )

    return {
        "request": request,
        "readings": readings,
        "periodNote": period_note,
    }
