from __future__ import annotations

import asyncio
import os
from datetime import date, timedelta
from typing import Any

import asyncpg

pool: asyncpg.Pool | None = None


async def initialize_database() -> None:
    global pool
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is required for the weather bot service.")
    if database_url.startswith("postgres://"):
        database_url = "postgresql://" + database_url.removeprefix("postgres://")

    pool = await asyncpg.create_pool(
        database_url,
        min_size=1,
        max_size=10,
        command_timeout=30,
    )
    async with pool.acquire() as connection:
        await connection.execute(
            """
            CREATE TABLE IF NOT EXISTS weather_requests (
                id BIGSERIAL PRIMARY KEY,
                latitude DOUBLE PRECISION NOT NULL,
                longitude DOUBLE PRECISION NOT NULL,
                requested_date TEXT NOT NULL,
                request_type TEXT NOT NULL CHECK (request_type IN ('date', 'year')),
                status TEXT NOT NULL CHECK (status IN ('success', 'error')),
                source TEXT NOT NULL CHECK (source IN ('forecast', 'historical', 'mixed')),
                temperature DOUBLE PRECISION,
                humidity DOUBLE PRECISION,
                dew_point DOUBLE PRECISION,
                conditions TEXT,
                response_ms INTEGER NOT NULL DEFAULT 0,
                user_name TEXT NOT NULL DEFAULT 'Telegram',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        await connection.execute(
            """
            CREATE TABLE IF NOT EXISTS bot_logs (
                id BIGSERIAL PRIMARY KEY,
                level TEXT NOT NULL CHECK (level IN ('info', 'warning', 'error')),
                source TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        await connection.execute(
            """
            CREATE INDEX IF NOT EXISTS weather_requests_created_at_idx
            ON weather_requests (created_at DESC)
            """
        )
        await connection.execute(
            """
            CREATE INDEX IF NOT EXISTS bot_logs_created_at_idx
            ON bot_logs (created_at DESC)
            """
        )


def require_pool() -> asyncpg.Pool:
    if pool is None:
        raise RuntimeError("The weather bot database has not been initialized.")
    return pool


def serialize_request(row: asyncpg.Record | dict[str, Any]) -> dict[str, Any]:
    return {
        "id": int(row["id"]),
        "latitude": float(row["latitude"]),
        "longitude": float(row["longitude"]),
        "requestedDate": row["requested_date"],
        "requestType": row["request_type"],
        "status": row["status"],
        "source": row["source"],
        "temperature": row["temperature"],
        "humidity": row["humidity"],
        "dewPoint": row["dew_point"],
        "conditions": row["conditions"],
        "responseMs": int(row["response_ms"]),
        "user": row["user_name"],
        "createdAt": row["created_at"].isoformat(),
    }


async def record_request(
    *,
    latitude: float,
    longitude: float,
    requested_date: str,
    request_type: str,
    status: str,
    source: str,
    response_ms: int,
    user_name: str,
    temperature: float | None = None,
    humidity: float | None = None,
    dew_point: float | None = None,
    conditions: str | None = None,
) -> dict[str, Any]:
    row = await require_pool().fetchrow(
        """
        INSERT INTO weather_requests (
            latitude, longitude, requested_date, request_type, status, source,
            temperature, humidity, dew_point, conditions, response_ms, user_name
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *
        """,
        latitude,
        longitude,
        requested_date,
        request_type,
        status,
        source,
        temperature,
        humidity,
        dew_point,
        conditions,
        response_ms,
        user_name,
    )
    return serialize_request(row)


async def write_log(level: str, source: str, message: str) -> None:
    await require_pool().execute(
        """
        INSERT INTO bot_logs (level, source, message)
        VALUES ($1, $2, $3)
        """,
        level,
        source,
        message[:1000],
    )


async def list_requests(limit: int, search: str | None) -> list[dict[str, Any]]:
    pattern = f"%{search.strip()}%" if search and search.strip() else None
    rows = await require_pool().fetch(
        """
        SELECT *
        FROM weather_requests
        WHERE $1::text IS NULL
           OR requested_date ILIKE $1
           OR status ILIKE $1
           OR user_name ILIKE $1
           OR conditions ILIKE $1
           OR latitude::text ILIKE $1
           OR longitude::text ILIKE $1
        ORDER BY created_at DESC
        LIMIT $2
        """,
        pattern,
        limit,
    )
    return [serialize_request(row) for row in rows]


async def list_logs(level: str, search: str | None, limit: int) -> list[dict[str, Any]]:
    pattern = f"%{search.strip()}%" if search and search.strip() else None
    rows = await require_pool().fetch(
        """
        SELECT id, level, source, message, created_at
        FROM bot_logs
        WHERE ($1::text = 'all' OR level = $1)
          AND ($2::text IS NULL OR message ILIKE $2 OR source ILIKE $2)
        ORDER BY created_at DESC
        LIMIT $3
        """,
        level,
        pattern,
        limit,
    )
    return [
        {
            "id": int(row["id"]),
            "level": row["level"],
            "source": row["source"],
            "message": row["message"],
            "createdAt": row["created_at"].isoformat(),
        }
        for row in rows
    ]


async def dashboard_summary(bot_status: str) -> dict[str, Any]:
    database = require_pool()
    totals, today, users, trend_rows, recent_rows = await asyncio.gather(
        database.fetchrow(
            """
            SELECT COUNT(*) AS total,
                   COUNT(*) FILTER (WHERE status = 'success') AS successes,
                   COALESCE(AVG(response_ms) FILTER (WHERE status = 'success'), 0) AS avg_ms
            FROM weather_requests
            """
        ),
        database.fetchrow(
            """
            SELECT COUNT(*) AS total
            FROM weather_requests
            WHERE created_at >= date_trunc('day', NOW())
            """
        ),
        database.fetchval(
            """
            SELECT COUNT(DISTINCT user_name)
            FROM weather_requests
            WHERE created_at >= NOW() - INTERVAL '24 hours'
            """
        ),
        database.fetch(
            """
            SELECT date_trunc('day', created_at)::date AS day, COUNT(*) AS count
            FROM weather_requests
            WHERE created_at >= CURRENT_DATE - INTERVAL '6 days'
            GROUP BY day
            ORDER BY day
            """
        ),
        database.fetch(
            """
            SELECT *
            FROM weather_requests
            ORDER BY created_at DESC
            LIMIT 6
            """
        ),
    )

    trend_by_day = {row["day"].isoformat(): int(row["count"]) for row in trend_rows}
    today_date = date.today()
    requests_trend = [
        {
            "label": (today_date - timedelta(days=offset)).strftime("%a"),
            "requests": trend_by_day.get(
                (today_date - timedelta(days=offset)).isoformat(), 0
            ),
        }
        for offset in reversed(range(7))
    ]

    total_count = int(totals["total"])
    success_count = int(totals["successes"])
    return {
        "status": "online",
        "botStatus": bot_status,
        "requestsToday": int(today["total"]),
        "requestsTotal": total_count,
        "successfulRequests": success_count,
        "successRate": round((success_count / total_count) * 100, 1)
        if total_count
        else 0,
        "avgResponseMs": int(round(float(totals["avg_ms"]))),
        "activeUsers": int(users or 0),
        "requestsTrend": requests_trend,
        "recentRequests": [serialize_request(row) for row in recent_rows],
    }


async def close_database() -> None:
    global pool
    if pool is not None:
        await pool.close()
        pool = None
