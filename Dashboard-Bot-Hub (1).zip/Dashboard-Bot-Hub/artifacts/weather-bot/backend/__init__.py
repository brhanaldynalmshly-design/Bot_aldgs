"""Python services for the global weather Telegram bot."""
