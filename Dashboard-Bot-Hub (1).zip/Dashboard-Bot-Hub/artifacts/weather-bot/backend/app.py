from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from database import (
    close_database,
    dashboard_summary,
    initialize_database,
    list_logs,
    list_requests,
    write_log,
)
from telegram_bot import get_telegram_status, run_telegram_bot
from weather import WeatherInputError, WeatherProviderError, execute_weather_request

_bot_task: asyncio.Task[None] | None = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global _bot_task
    await initialize_database()
    await write_log("info", "system", "Weather bot service started.")
    _bot_task = asyncio.create_task(run_telegram_bot())
    try:
        yield
    finally:
        if _bot_task is not None:
            _bot_task.cancel()
            try:
                await _bot_task
            except asyncio.CancelledError:
                pass
            _bot_task = None
        await close_database()


app = FastAPI(
    title="Global Weather Bot API",
    description="Weather request, Telegram bot, and operations dashboard service.",
    version="1.0.0",
    lifespan=lifespan,
)


class WeatherRequestInput(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    dateOrYear: str = Field(min_length=4, max_length=10)


@app.get("/weather-api/healthz")
async def health_check() -> dict[str, object]:
    return {
        "status": "ok",
        "botStatus": get_telegram_status(),
        "providerConfigured": bool(os.getenv("VISUAL_CROSSING_API_KEY")),
    }


@app.get("/weather-api/dashboard")
async def get_dashboard() -> dict[str, object]:
    return await dashboard_summary(get_telegram_status())


@app.get("/weather-api/requests")
async def get_weather_requests(
    limit: int = Query(default=25, ge=1, le=100),
    search: str | None = None,
) -> list[dict[str, object]]:
    return await list_requests(limit, search)


@app.post("/weather-api/requests")
async def create_weather_request(
    request: WeatherRequestInput,
) -> dict[str, object]:
    try:
        return await execute_weather_request(
            request.latitude,
            request.longitude,
            request.dateOrYear,
            user_name="Dashboard",
        )
    except WeatherInputError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except WeatherProviderError as error:
        raise HTTPException(status_code=502, detail=str(error)) from error


@app.get("/weather-api/logs")
async def get_bot_logs(
    level: Literal["all", "info", "warning", "error"] = "all",
    search: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
) -> list[dict[str, object]]:
    return await list_logs(level, search, limit)
