import telebot
import requests
from telebot import types
from datetime import datetime, timedelta

# مفاتيح الربط السحابية الخاصة بك
BOT_TOKEN = "9295163158:AAF12Nz6bNi9Pmzoq4-nJugH2pPEfe7_6kM"
WEATHER_KEY = "Z8QW3GVHA57K5D86DGHZCWU5J"

bot = telebot.TeleBot(BOT_TOKEN)
user_sessions = {}

# دالة هندسية مخصصة لتوليد أزرار الـ 24 ساعة بشكل منفرد ومنظم مريح للهاتف
def get_hours_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=3)
    
    # زر الفحص الشامل المخصص لصقيع فجر جهاد
    btn_frost = types.InlineKeyboardButton("🔬 فحص صقيع الفجر الشامل (5 - 6 صباحاً)", callback_data="hr_frost")
    markup.add(btn_frost)
    
    hour_buttons = []
    for h in range(24):
        if h == 0: display_label = "12 منتصف الليل"
        elif h == 12: display_label = "12 ظهراً"
        elif h < 12: display_label = f"{h} صباحاً"
        else: display_label = f"{h-12} مساءً"
        
        btn = types.InlineKeyboardButton(display_label, callback_data=f"hr_{h:02d}")
        hour_buttons.append(btn)
    
    for i in range(0, len(hour_buttons), 3):
        markup.add(*hour_buttons[i:i+3])
    return markup

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    markup = types.ReplyKeyboardMarkup(row_width=1, resize_keyboard=True, one_time_keyboard=True)
    location_button = types.KeyboardButton(text="ارسل موقعك الحالي 📍", request_location=True)
    markup.add(location_button)
    
    welcome_text = (
        "🌍 **مرحباً بك في بوت الطقس الذكي وفحص الصقيع (النسخة المتكاملة)!**\n\n"
        "ℹ️ **طرق الاستخدام البديلة:**\n"
        "1️⃣ اضغط على الزر بالأسفل لـ **إرسال موقعك الحالي 📍** عبر الـ GPS.\n"
        "2️⃣ أو **اكتب اسم منطقتك، المديرية، أو العزلة مباشرة** في الشات (مثال: `ريدة` أو `عمران`).\n\n"
        "👇 ابدأ الآن بمشاركة موقعك أو كتابة اسم منطقتك:"
    )
    bot.send_message(message.chat.id, welcome_text, parse_mode="Markdown", reply_markup=markup)

@bot.message_handler(content_types=['location'])
def handle_location(message):
    if message.location is not None:
        user_sessions[message.chat.id] = {
            "lat": message.location.latitude,
            "lon": message.location.longitude,
            "location_name": "موقعك المرسل"
        }
        show_day_options(message.chat.id)

@bot.message_handler(func=lambda message: True)
def handle_text_location(message):
    location_query = message.text.strip()
    if location_query.startswith('/'): return

    bot.send_message(message.chat.id, f"🔍 جاري البحث عن إحداثيات الجغرافية لـ ({location_query}) وتحديد معالمها...")
    
    url = f"https://visualcrossing.com{location_query}"
    query_params = {"key": WEATHER_KEY, "contentType": "json"}
    
    try:
        response = requests.get(url, params=query_params, headers={"User-Agent": "Mozilla/5.0"})
        if response.status_code == 200:
            data = response.json()
            user_sessions[message.chat.id] = {
                "lat": data.get('latitude'),
                "lon": data.get('longitude'),
                "location_name": location_query
            }
            show_day_options(message.chat.id)
        else:
            bot.send_message(message.chat.id, "❌ لم نتمكن من العثور على اسم هذه المنطقة. يرجى التحقق من الاسم أو إرسال الموقع الجغرافي 📍")
    except Exception:
        bot.send_message(message.chat.id, "⚠️ حدث خطأ أثناء البحث عن المنطقة.")

def show_day_options(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn_today = types.InlineKeyboardButton("☀️ طقس اليوم", callback_data="day_today")
    btn_tomorrow = types.InlineKeyboardButton("🔮 طقس الغد", callback_data="day_tomorrow")
    markup.add(btn_today, btn_tomorrow)
    
    loc_name = user_sessions[chat_id].get("location_name", "المنطقة المحددة")
    bot.send_message(chat_id, f"📍 تم تحديد موقع ({loc_name}) بنجاح!\nيرجى اختيار اليوم أولاً:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith('day_'))
def handle_day_selection(call):
    chat_id = call.message.chat.id
    if chat_id not in user_sessions:
        bot.send_message(chat_id, "⚠️ يرجى تحديد الموقع أولاً.")
        return
        
    current_date = datetime.now()
    if call.data == "day_tomorrow":
        target_date = (current_date + timedelta(days=1)).strftime("%Y-%m-%d")
        day_label = "الغد"
    else:
        target_date = current_date.strftime("%Y-%m-%d")
        day_label = "اليوم"
        
    user_sessions[chat_id]["date"] = target_date
    user_sessions[chat_id]["label"] = day_label
    
    markup = get_hours_keyboard()
    bot.edit_message_text(f"📆 اخترت طقس {day_label} ({target_date}).\n👇 حدد الآن الساعة المطلوبة لعرض مؤشرات الطقس وعوامل الصقيع:", 
                          chat_id=chat_id, message_id=call.message.message_id, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith(('hr_', 'back_main')))
def handle_hour_or_back(call):
    chat_id = call.message.chat.id
    if chat_id not in user_sessions or "date" not in user_sessions[chat_id]:
        bot.send_message(chat_id, "⚠️ انتهت الجلسة، يرجى البدء من جديد عبر أمر /start")
        return
        
    session = user_sessions[chat_id]
    
    if call.data == "back_main":
        markup = get_hours_keyboard()
        bot.edit_message_text(f"📆 طقس {session['label']} ({session['date']}).\n👇 حدد الساعة المطلوبة للتحليل مجدداً:", 
                              chat_id=chat_id, message_id=call.message.message_id, reply_markup=markup)
        return

    target_hr = call.data.replace("hr_", "")
    url = f"https://visualcrossing.com{session['lat']},{session['lon']}/{session['date']}"
    query_params = {"key": WEATHER_KEY, "unitGroup": "metric", "include": "hours", "contentType": "json"}
    
    try:
        response = requests.get(url, params=query_params, headers={"User-Agent": "Mozilla/5.0"})
        if response.status_code == 200:
            data = response.json()
            hours_data = data.get('days', [{}]).get('hours', [])
            
            response_text = f"📊 **تحليل الطقس ومؤشرات الصقيع لـ ({session['location_name']}):**\n"
            frost_alert = False
            
            for h in hours_data:
                time_str = h.get('datetime', '')
                hour_int = int(time_str.split(':')[0])
                
                is_target = False
                if target_hr == "frost" and hour_int in: is_target = True
                elif target_hr != "frost" and hour_int == int(target_hr): is_target = True
                    
                if is_target:
                    temp = h.get('temp')
                    humidity = h.get('humidity')
                    dew_point = h.get('dewpoint')
                    wind = h.get('windspeed', 0)
                    
                    if hour_int == 0: arabic_time = "12:00 منتصف الليل"
                    elif hour_int == 12: arabic_time = "12:00 ظهراً"
                    elif hour_int < 12: arabic_time = f"{hour_int:02d}:00 صباحاً"
                    else: arabic_time = f"{(hour_int-12):02d}:00 مساءً"
                    
                    response_text += (
                        f"\n⏱️ **التوقيت: {arabic_time}**\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"🌡️ درجة الحرارة: {temp} م°\n"
                        f"💧 الرطوبة: {humidity}%\n"
                        f"🌫️ نقطة التكثف: {dew_point} م°\n"
                        f"💨 سرعة الرياح: {wind} كم/س\n"
                        f"──────────────────\n"
                    )
                    if temp <= 3.0 and dew_point <= 0.0: frost_alert = True
            
            if target_hr == "frost" and frost_alert:
                response_text += "\n🚨 **تحذير صقيع الفجر المباشر:** تم رصد مؤشرات صقيع عالية جداً بين الساعة 5 و 6 صباحاً! يرجى حماية النباتات والمزروعات فوراً."
            
            back_markup = types.InlineKeyboardMarkup()
            back_markup.add(types.InlineKeyboardButton("↩️ العودة لقائمة الساعات", callback_data="back_main"))
            
            bot.send_message(chat_id, response_text, parse_mode="Markdown", reply_markup=back_markup)
        else:
            bot.send_message(chat_id, "❌ واجه السيرفر مشكلة في سحب تفاصيل ساعات الطقس.")
    except Exception:
        bot.send_message(chat_id, "⚠️ حدث خطأ أثناء معالجة تفاصيل طقس الساعة المحددة.")

bot.infinity_polling()
