# Global Weather Bot

A Python Telegram bot and operations API with a React web dashboard. Weather requests use Visual Crossing and are stored with service logs in PostgreSQL.

## Telegram commands

- `/start` — show an Arabic welcome message and the live-location button
- `/help` — show Arabic usage instructions
- `/weather <latitude> <longitude> <YYYY-MM-DD>` — query one day
- `/weather <latitude> <longitude> <YYYY>` — query a year
- Share your location to receive inline choices for the location's current local day or tomorrow, then select dawn, noon, evening, or the full-day report. You may also send all three `/weather` values separated by spaces or commas.

Telegram replies are formatted in Arabic. Daily reports include minimum and maximum temperature, and date lookups include hourly temperature, humidity, dew point, and wind speed in local time. A bold frost warning appears when an hour is at or below 2°C and its dew point is below 0°C. The dawn section calls out 05:00 and 06:00; an urgent warning appears when either hour is at or below 3°C with a dew point at or below 0°C. Year lookups include a daily summary for each returned day; their frost warnings use the daily low and daily dew point. Past dates and completed years are historical observations. Future requests are limited to the provider's available forecast horizon; unsupported future dates are rejected.

## Configuration

Add these as Replit Secrets:

- `TELEGRAM_BOT_TOKEN`
- `VISUAL_CROSSING_API_KEY`

The Python service also uses the workspace `DATABASE_URL`.

## Development

- Dashboard: `pnpm --filter @workspace/weather-bot run dev`
- Python API and Telegram bot: `uv run --project . uvicorn app:app --app-dir artifacts/weather-bot/backend --host 0.0.0.0 --port 8001`
- API paths: `/weather-api/healthz`, `/weather-api/dashboard`, `/weather-api/requests`, and `/weather-api/logs`
