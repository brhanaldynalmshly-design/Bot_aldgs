import { useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity, ArrowUpRight, Bot, Check, CheckCircle2, ChevronDown,
  Clock3, Cloud, CloudSun, Command, ExternalLink, Filter, Globe2, Loader2, MapPin,
  Menu, RefreshCw, Search, Send, Server, ShieldCheck, Terminal, Thermometer, X, XCircle,
} from 'lucide-react';
import {
  getGetBotLogsQueryKey, getGetDashboardQueryKey, getGetWeatherRequestsQueryKey,
  useCreateWeatherRequest, useGetBotLogs, useGetDashboard, useGetWeatherRequests,
  useHealthCheck,
} from '@workspace/api-client-react';
import type { LogEntry, WeatherQueryResult, WeatherRequest } from '@workspace/api-client-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type Section = 'overview' | 'requests' | 'logs';
const navItems: { id: Section; label: string; icon: typeof Activity }[] = [
  { id: 'overview', label: 'Overview', icon: Activity },
  { id: 'requests', label: 'Request history', icon: Globe2 },
  { id: 'logs', label: 'Bot logs', icon: Terminal },
];

function formatDate(value?: string) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('en', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  }).format(date);
}
function number(value?: number | null, digits = 1) {
  return value == null || !Number.isFinite(value) ? '—' : value.toFixed(digits);
}
function StatusPill({ status }: { status?: string }) {
  const healthy = ['healthy', 'online', 'running', 'success', 'ok'].includes((status || '').toLowerCase());
  return <span className={`inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-wide ${healthy ? 'bg-[#e0eee8] text-[#28684f]' : 'bg-[#f5e6df] text-[#a34d37]'}`}>
    <span className={`h-1.5 w-1.5 rounded-full ${healthy ? 'bg-[#398b68] pulse-dot' : 'bg-[#c3654d]'}`} />{status || 'unknown'}
  </span>;
}
function RequestRows({ requests, emptyTitle = 'No requests yet', emptyText = 'Requests from Telegram will appear here.' }: { requests: WeatherRequest[]; emptyTitle?: string; emptyText?: string }) {
  if (!requests.length) return <div className="grid min-h-56 place-items-center px-6 text-center">
    <div><div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-full bg-[#e8efeb] text-[#387365]"><Cloud size={20} /></div><h3 className="font-display text-base font-bold">{emptyTitle}</h3><p className="mt-1 max-w-sm text-sm text-muted-foreground">{emptyText}</p></div>
  </div>;
  return <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left">
    <thead><tr className="border-b border-border text-[10px] font-bold uppercase tracking-[.14em] text-muted-foreground">
      <th className="px-5 py-3">Request</th><th className="px-4 py-3">Location</th><th className="px-4 py-3">Weather</th><th className="px-4 py-3">Source</th><th className="px-4 py-3">Response</th><th className="px-5 py-3 text-right">Received</th>
    </tr></thead>
    <tbody>{requests.map((item) => <tr key={item.id} data-testid={`row-request-${item.id}`} className="border-b border-border/70 last:border-0 hover:bg-[#f3f4ed]">
      <td className="px-5 py-4"><div className="flex items-center gap-2"><span className={`grid h-6 w-6 place-items-center rounded-full ${item.status === 'success' ? 'bg-[#e1eee8] text-[#327354]' : 'bg-[#f5e5de] text-[#a94f39]'}`}>{item.status === 'success' ? <Check size={13} /> : <X size={13} />}</span><div><p className="text-sm font-semibold">{item.requestType === 'year' ? `Year ${item.requestedDate}` : item.requestedDate}</p><p className="text-[11px] text-muted-foreground">#{item.id} · {item.user || 'Telegram user'}</p></div></div></td>
      <td className="px-4 py-4"><span className="mono text-xs text-foreground/80">{number(item.latitude, 2)}, {number(item.longitude, 2)}</span></td>
      <td className="px-4 py-4">{item.status === 'success' ? <div><span className="font-display text-sm font-bold">{number(item.temperature)}°</span><span className="ml-2 text-xs text-muted-foreground">{number(item.humidity, 0)}% RH</span><p className="mt-0.5 max-w-[150px] truncate text-[11px] text-muted-foreground">{item.conditions || 'Conditions unavailable'}</p></div> : <span className="text-xs text-[#a94f39]">Request failed</span>}</td>
      <td className="px-4 py-4"><span className={`rounded-md px-2 py-1 text-[10px] font-semibold uppercase tracking-wider ${item.source === 'forecast' ? 'bg-[#e6eff1] text-[#316d78]' : 'bg-[#f1eadb] text-[#896c32]'}`}>{item.source || '—'}</span></td>
      <td className="px-4 py-4"><span className="mono text-xs">{item.responseMs} ms</span></td><td className="px-5 py-4 text-right text-xs text-muted-foreground">{formatDate(item.createdAt)}</td>
    </tr>)}</tbody>
  </table></div>;
}
function Metric({ label, value, detail, icon: Icon, accent, trend }: { label: string; value: string; detail: string; icon: typeof Activity; accent: string; trend?: string }) {
  return <article className="rounded-xl border border-border bg-card p-5 shadow-[0_2px_8px_rgba(37,57,52,.035)]">
    <div className="flex items-start justify-between"><div className="text-[11px] font-bold uppercase tracking-[.12em] text-muted-foreground">{label}</div><span className={`grid h-9 w-9 place-items-center rounded-lg ${accent}`}><Icon size={17} /></span></div>
    <div className="mt-5 flex items-baseline gap-2"><strong className="font-display text-[30px] font-extrabold leading-none tracking-[-.045em]">{value}</strong>{trend && <span className="inline-flex items-center text-[11px] font-semibold text-[#397a5e]"><ArrowUpRight size={13} />{trend}</span>}</div>
    <p className="mt-2 text-xs text-muted-foreground">{detail}</p>
  </article>;
}
function TrendChart({ points }: { points: { label: string; requests: number }[] }) {
  const max = Math.max(1, ...points.map((p) => p.requests));
  const bars = points.slice(-12);
  return <div className="flex h-[130px] items-end gap-2 pt-4">
    {bars.length ? bars.map((point, index) => <div key={`${point.label}-${index}`} className="group flex h-full flex-1 flex-col justify-end">
      <div title={`${point.label}: ${point.requests} requests`} className="relative w-full rounded-t-[3px] bg-[#72a99c] transition-colors group-hover:bg-[#316e68]" style={{ height: `${Math.max(5, point.requests / max * 100)}%` }} />
      <span className="mt-2 truncate text-center text-[9px] text-muted-foreground">{point.label}</span>
    </div>) : <div className="grid h-full w-full place-items-center text-xs text-muted-foreground">Trend data will appear after requests are recorded.</div>}
  </div>;
}
function LogList({ entries }: { entries: LogEntry[] }) {
  if (!entries.length) return <div className="grid min-h-56 place-items-center px-6 text-center"><div><div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-full bg-[#e8efeb] text-[#387365]"><Terminal size={19} /></div><h3 className="font-display text-base font-bold">Quiet on the wire</h3><p className="mt-1 text-sm text-muted-foreground">Service and bot events will be recorded here.</p></div></div>;
  return <div className="divide-y divide-border/70">{entries.map((entry) => <div key={entry.id} data-testid={`log-entry-${entry.id}`} className="flex gap-3 px-5 py-4">
    <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${entry.level === 'error' ? 'bg-[#c45c45]' : entry.level === 'warning' ? 'bg-[#d99a3d]' : 'bg-[#4c9a79]'}`} />
    <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-x-2 gap-y-1"><span className="mono text-[10px] uppercase tracking-[.12em] text-muted-foreground">{entry.level}</span><span className="text-[11px] font-semibold text-[#47766f]">{entry.source}</span><span className="ml-auto text-[10px] text-muted-foreground">{formatDate(entry.createdAt)}</span></div><p className="mt-1 break-words text-sm text-foreground/85">{entry.message}</p></div>
  </div>)}</div>;
}

function Home() {
  const [section, setSection] = useState<Section>('overview');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [search, setSearch] = useState('');
  const [logLevel, setLogLevel] = useState('all');
  const [lookupOpen, setLookupOpen] = useState(false);
  const [coords, setCoords] = useState({ latitude: '', longitude: '', dateOrYear: '' });
  const [lookupResult, setLookupResult] = useState<WeatherQueryResult | null>(null);
  const [lookupError, setLookupError] = useState('');
  const queryClient = useQueryClient();
  const dashboardQuery = useGetDashboard({ query: { refetchInterval: 30000 } });
  const healthQuery = useHealthCheck({ query: { refetchInterval: 30000 } });
  const requestsQuery = useGetWeatherRequests({ limit: 100, search: search || undefined }, { query: { refetchInterval: 30000 } });
  const logsQuery = useGetBotLogs({ limit: 100, level: logLevel === 'all' ? undefined : logLevel as 'info' | 'warning' | 'error' }, { query: { refetchInterval: 30000 } });
  const createRequest = useCreateWeatherRequest();
  const dashboard = dashboardQuery.data;
  const requests = requestsQuery.data || [];
  const logs = logsQuery.data || [];
  const trend = useMemo(() => dashboard?.requestsTrend || [], [dashboard?.requestsTrend]);
  const healthy = (healthQuery.data?.status || dashboard?.status || '').toLowerCase();
  const serviceReady = ['healthy', 'ok', 'online', 'running'].includes(healthy);

  async function submitLookup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLookupError('');
    setLookupResult(null);
    const latitude = Number(coords.latitude), longitude = Number(coords.longitude);
    if (!coords.latitude || !coords.longitude || !Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
      setLookupError('Latitude must be between −90 and 90.'); return;
    }
    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
      setLookupError('Longitude must be between −180 and 180.'); return;
    }
    if (!/^\d{4}(?:-\d{2}-\d{2})?$/.test(coords.dateOrYear)) {
      setLookupError('Enter a year (YYYY) or a date (YYYY-MM-DD).'); return;
    }
    createRequest.mutate({ data: { latitude, longitude, dateOrYear: coords.dateOrYear } }, {
      onSuccess: (result) => {
        setLookupResult(result);
        void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetWeatherRequestsQueryKey({ limit: 100, search: search || undefined }) });
        void queryClient.invalidateQueries({ queryKey: getGetBotLogsQueryKey({ limit: 100 }) });
      },
      onError: (error) => setLookupError(error instanceof Error ? error.message : 'The weather request could not be completed. Try again.'),
    });
  }
  function refreshAll() {
    void dashboardQuery.refetch(); void healthQuery.refetch(); void requestsQuery.refetch(); void logsQuery.refetch();
  }
  const selectedNav = navItems.find((item) => item.id === section);

  return <div className="min-h-[100dvh] bg-background text-foreground">
    <aside className={`${mobileMenu ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0`}>
      <div className="flex h-[78px] items-center gap-3 border-b border-sidebar-border px-6">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#eeb85f] text-[#203a3d]"><CloudSun size={21} strokeWidth={2.1} /></div>
        <div><div className="font-display text-[15px] font-extrabold tracking-[-.03em]">weather<span className="text-[#eeb85f]">bot</span></div><div className="mono mt-0.5 text-[9px] uppercase tracking-[.2em] text-sidebar-foreground/55">operations console</div></div>
        <button onClick={() => setMobileMenu(false)} className="ml-auto rounded-md p-1 text-sidebar-foreground/60 md:hidden" aria-label="Close navigation"><X size={18} /></button>
      </div>
      <div className="px-4 pt-8"><div className="mb-3 px-3 text-[9px] font-bold uppercase tracking-[.2em] text-sidebar-foreground/40">Workspace</div>
        <nav className="space-y-1">{navItems.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => { setSection(id); setMobileMenu(false); }} data-testid={`nav-${id}`} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] font-medium transition-colors ${section === id ? 'bg-sidebar-accent text-white' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{id === 'logs' && <span className="ml-auto rounded-full bg-sidebar-accent px-2 py-0.5 text-[10px] text-sidebar-foreground/70">{logs.length || '—'}</span>}</button>)}</nav>
      </div>
      <div className="mt-auto p-4">
        <div className="rounded-xl border border-sidebar-border bg-[#19343a] p-4">
          <div className="flex items-center gap-2 text-[11px] font-semibold"><span className={`h-2 w-2 rounded-full ${healthQuery.isLoading ? 'bg-[#eeb85f] animate-pulse' : serviceReady ? 'bg-[#73c092] pulse-dot' : 'bg-[#d77b61]'}`} />Service status</div>
          <div className="mt-2 flex items-center justify-between"><span className="text-xs text-sidebar-foreground/60">API</span><span className="mono text-[10px] text-sidebar-foreground/80">{healthQuery.data?.status || (healthQuery.isLoading ? 'checking' : 'unavailable')}</span></div>
          <div className="mt-1 flex items-center justify-between"><span className="text-xs text-sidebar-foreground/60">Telegram bot</span><span className="mono text-[10px] text-sidebar-foreground/80">{healthQuery.data?.botStatus || dashboard?.botStatus || '—'}</span></div>
        </div>
        <div className="mt-4 flex items-center justify-between px-1 text-[10px] text-sidebar-foreground/40"><span>GLOBAL WEATHER SERVICE</span><span className="mono">v1.0</span></div>
      </div>
    </aside>
    {mobileMenu && <button aria-label="Close menu overlay" onClick={() => setMobileMenu(false)} className="fixed inset-0 z-30 bg-[#132c31]/45 md:hidden" />}
    <main className="min-h-[100dvh] md:pl-[248px]">
      <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-border/80 bg-background/95 px-5 backdrop-blur-md md:px-9">
        <div className="flex items-center gap-3"><button className="rounded-lg p-2 hover:bg-muted md:hidden" onClick={() => setMobileMenu(true)} aria-label="Open navigation"><Menu size={19} /></button><div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex"><span>Weather bot</span><span>/</span><span className="font-semibold text-foreground">{selectedNav?.label}</span></div><h1 className="font-display text-sm font-bold sm:hidden">{selectedNav?.label}</h1></div>
        <div className="flex items-center gap-2.5"><div className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-[10px] text-muted-foreground sm:flex"><span className={`h-1.5 w-1.5 rounded-full ${serviceReady ? 'bg-[#45956f]' : 'bg-[#d49b46]'}`} />{serviceReady ? 'All systems operational' : 'Checking service'}</div>
          <button onClick={refreshAll} className="inline-flex h-9 items-center gap-2 rounded-lg border border-border bg-card px-3 text-xs font-semibold hover:bg-muted" data-testid="button-refresh"><RefreshCw size={14} className={dashboardQuery.isFetching ? 'animate-spin' : ''} /><span className="hidden sm:inline">Refresh</span></button>
          <button onClick={() => { setLookupOpen(true); setLookupResult(null); setLookupError(''); }} className="inline-flex h-9 items-center gap-2 rounded-lg bg-primary px-3.5 text-xs font-bold text-primary-foreground shadow-sm hover:brightness-95" data-testid="button-new-lookup"><MapPin size={14} />New lookup</button>
        </div>
      </header>

      <div className="mx-auto max-w-[1450px] px-5 pb-12 pt-7 md:px-9 md:pt-9">
        <div className="rise-in mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div><div className="mono mb-2 text-[10px] uppercase tracking-[.22em] text-[#568078]">Live operations · global coverage</div><h2 className="font-display text-[28px] font-extrabold tracking-[-.05em] md:text-[34px]">{section === 'overview' ? 'Weather command center' : section === 'requests' ? 'Request history' : 'Bot activity log'}</h2><p className="mt-1.5 max-w-xl text-sm text-muted-foreground">{section === 'overview' ? 'A clear view of every coordinate request flowing through Telegram.' : section === 'requests' ? 'Inspect historical observations and available forecasts, request by request.' : 'Service events and bot messages, newest first.'}</p></div>
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground"><Clock3 size={13} />Auto-refresh every 30 seconds</div>
        </div>

        {section === 'overview' && <>
          <div className="rise-in mb-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Metric label="Requests today" value={dashboard ? dashboard.requestsToday.toLocaleString() : '—'} detail="Incoming weather lookups" icon={Send} accent="bg-[#e6efed] text-[#31746e]" trend={dashboard ? undefined : undefined} />
            <Metric label="Successful requests" value={dashboard ? dashboard.successfulRequests.toLocaleString() : '—'} detail={`${dashboard ? number(dashboard.successRate, 1) : '—'}% lifetime success rate`} icon={CheckCircle2} accent="bg-[#e4eee4] text-[#4e805c]" />
            <Metric label="Avg. response time" value={dashboard ? `${Math.round(dashboard.avgResponseMs)} ms` : '—'} detail="Weather provider round-trip" icon={Clock3} accent="bg-[#f2ecdc] text-[#927139]" />
            <Metric label="Active users" value={dashboard ? dashboard.activeUsers.toLocaleString() : '—'} detail="Unique users today" icon={Globe2} accent="bg-[#e9eaf0] text-[#586982]" />
          </div>
          <div className="mb-6 grid gap-5 xl:grid-cols-[1.45fr_.85fr]">
            <section className="weather-grid overflow-hidden rounded-xl border border-border bg-card p-5 md:p-6">
              <div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-lg bg-[#e3efed] text-[#34766e]"><Activity size={15} /></span><h3 className="font-display text-sm font-bold">Request volume</h3></div><p className="mt-2 text-xs text-muted-foreground">Requests received over the recent period</p></div><div className="text-right"><div className="font-display text-2xl font-extrabold tracking-tight">{dashboard ? dashboard.requestsTotal.toLocaleString() : '—'}</div><div className="text-[10px] uppercase tracking-widest text-muted-foreground">all-time</div></div></div>
              {dashboardQuery.isLoading ? <div className="mt-6 h-[130px] animate-pulse rounded bg-muted/70" /> : dashboardQuery.isError ? <div className="mt-6 grid h-[130px] place-items-center text-center"><div><p className="text-sm font-semibold">Metrics are unavailable</p><button onClick={() => void dashboardQuery.refetch()} className="mt-2 text-xs font-semibold text-primary underline underline-offset-4">Retry dashboard data</button></div></div> : <TrendChart points={trend} />}
            </section>
            <section className="relative overflow-hidden rounded-xl bg-[#244c50] p-5 text-[#f6f1e4] md:p-6">
              <div className="absolute -right-6 -top-9 h-40 w-40 rounded-full border border-[#f1ca7b]/25" /><div className="absolute -right-1 top-4 h-28 w-28 rounded-full border border-[#f1ca7b]/15" />
              <div className="relative flex items-center justify-between"><div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.16em] text-[#e1c88f]"><ShieldCheck size={15} />System health</div><span className={`h-2 w-2 rounded-full ${serviceReady ? 'bg-[#80c99c] pulse-dot' : 'bg-[#e8af5c]'}`} /></div>
              <div className="relative mt-5 font-display text-[25px] font-extrabold tracking-[-.04em]">{healthQuery.isLoading ? 'Checking services' : serviceReady ? 'Everything is running' : 'Status needs attention'}</div>
              <p className="relative mt-1 max-w-sm text-xs leading-relaxed text-[#d4dfd6]/75">Weather lookups use Visual Crossing for historical observations and forecasts where available.</p>
              <div className="relative mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-lg border border-white/10 bg-white/[.06] p-3"><div className="flex items-center gap-1.5 text-[10px] text-[#d4dfd6]/65"><Server size={12} />API service</div><div className="mt-2"><StatusPill status={healthQuery.data?.status || (healthQuery.isLoading ? 'checking' : 'unknown')} /></div></div>
                <div className="rounded-lg border border-white/10 bg-white/[.06] p-3"><div className="flex items-center gap-1.5 text-[10px] text-[#d4dfd6]/65"><Bot size={12} />Telegram bot</div><div className="mt-2"><StatusPill status={healthQuery.data?.botStatus || dashboard?.botStatus} /></div></div>
              </div>
              {healthQuery.isError && <button onClick={() => void healthQuery.refetch()} className="relative mt-4 text-xs font-semibold text-[#edc87e] underline underline-offset-4">Retry service check</button>}
            </section>
          </div>
          <section className="overflow-hidden rounded-xl border border-border bg-card">
            <div className="flex flex-col justify-between gap-4 border-b border-border px-5 py-4 sm:flex-row sm:items-center md:px-6">
              <div><div className="flex items-center gap-2"><h3 className="font-display text-sm font-bold">Recent requests</h3><span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">{requests.length}</span></div><p className="mt-1 text-xs text-muted-foreground">Latest activity from the weather bot</p></div>
              <div className="flex items-center gap-2"><label className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input aria-label="Search requests" data-testid="input-search-requests" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search coordinates or user" className="h-9 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-xs outline-none focus:border-primary sm:w-[220px]" /></label><button onClick={() => setSection('requests')} className="hidden h-9 items-center gap-1 rounded-lg px-3 text-xs font-semibold text-primary hover:bg-muted sm:inline-flex">View all <ExternalLink size={12} /></button></div>
            </div>
            {requestsQuery.isLoading ? <div className="space-y-3 p-5">{[1,2,3].map((i) => <div key={i} className="h-12 animate-pulse rounded-md bg-muted/70" />)}</div> : requestsQuery.isError ? <div className="grid min-h-52 place-items-center text-center"><div><p className="text-sm font-semibold">Could not load request history</p><button onClick={() => void requestsQuery.refetch()} className="mt-2 text-xs font-semibold text-primary underline underline-offset-4">Try again</button></div></div> : <RequestRows requests={requests.slice(0, 8)} emptyTitle={search ? 'No matching requests' : undefined} emptyText={search ? 'Try another coordinate, date, or user.' : undefined} />}
          </section>
        </>}

        {section === 'requests' && <section className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex flex-col justify-between gap-3 border-b border-border px-5 py-4 md:flex-row md:items-center md:px-6"><div><h3 className="font-display text-sm font-bold">All weather requests</h3><p className="mt-1 text-xs text-muted-foreground">Coordinate lookups with source and response details</p></div><div className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input aria-label="Search request history" data-testid="input-history-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search requests" className="h-9 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-xs outline-none focus:border-primary sm:w-[240px]" /></div></div>
          {requestsQuery.isLoading ? <div className="space-y-3 p-5">{[1,2,3,4].map((i) => <div key={i} className="h-12 animate-pulse rounded-md bg-muted/70" />)}</div> : requestsQuery.isError ? <div className="grid min-h-64 place-items-center text-center"><div><p className="text-sm font-semibold">Request history is unavailable</p><p className="mt-1 text-xs text-muted-foreground">The service did not return request data.</p><button onClick={() => void requestsQuery.refetch()} className="mt-3 text-xs font-semibold text-primary underline underline-offset-4">Retry loading</button></div></div> : <RequestRows requests={requests} emptyTitle={search ? 'No matching requests' : 'No requests recorded'} emptyText={search ? 'Try a different search term.' : 'Once the bot receives a weather query, the full record will appear here.'} />}
        </section>}

        {section === 'logs' && <section className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex flex-col justify-between gap-3 border-b border-border px-5 py-4 md:flex-row md:items-center md:px-6"><div><div className="flex items-center gap-2"><h3 className="font-display text-sm font-bold">Service and bot logs</h3><span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">{logs.length} events</span></div><p className="mt-1 text-xs text-muted-foreground">Operational messages from the API and Telegram bot</p></div><label className="relative flex h-9 items-center gap-2 rounded-lg border border-input bg-background px-3 text-xs"><Filter size={13} className="text-muted-foreground" /><select aria-label="Filter log level" data-testid="select-log-level" value={logLevel} onChange={(e) => setLogLevel(e.target.value)} className="min-w-[100px] bg-transparent pr-1 outline-none"><option value="all">All levels</option><option value="info">Info</option><option value="warning">Warning</option><option value="error">Error</option></select><ChevronDown size={12} className="pointer-events-none text-muted-foreground" /></label></div>
          {logsQuery.isLoading ? <div className="space-y-4 p-5">{[1,2,3,4].map((i) => <div key={i} className="h-11 animate-pulse rounded bg-muted/70" />)}</div> : logsQuery.isError ? <div className="grid min-h-64 place-items-center text-center"><div><p className="text-sm font-semibold">Logs could not be loaded</p><button onClick={() => void logsQuery.refetch()} className="mt-2 text-xs font-semibold text-primary underline underline-offset-4">Retry log request</button></div></div> : <LogList entries={logs} />}
        </section>}
        <footer className="mt-7 flex flex-col gap-2 border-t border-border/70 pt-4 text-[10px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between"><span>Weather intelligence · Visual Crossing data provider</span><span className="mono">UTC · LIVE DATA</span></footer>
      </div>
    </main>

    {lookupOpen && <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#102c30]/55 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onMouseDown={(e) => { if (e.target === e.currentTarget) setLookupOpen(false); }}>
      <section role="dialog" aria-modal="true" aria-labelledby="lookup-title" className="rise-in max-h-[92dvh] w-full max-w-[570px] overflow-y-auto rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-2xl">
        <div className="flex items-start justify-between border-b border-border px-6 py-5"><div><div className="mono text-[9px] uppercase tracking-[.2em] text-[#568078]">Manual weather lookup</div><h2 id="lookup-title" className="mt-1 font-display text-xl font-extrabold tracking-[-.03em]">Query a place in time</h2><p className="mt-1 text-xs text-muted-foreground">Coordinates plus a date or year. No location names required.</p></div><button onClick={() => setLookupOpen(false)} aria-label="Close lookup" className="rounded-lg p-2 text-muted-foreground hover:bg-muted"><X size={17} /></button></div>
        <div className="p-6">
          {!lookupResult ? <form onSubmit={submitLookup} className="space-y-4">
            <div className="grid grid-cols-2 gap-3"><label className="space-y-1.5"><span className="text-xs font-semibold">Latitude</span><input data-testid="input-latitude" required type="number" step="any" min="-90" max="90" value={coords.latitude} onChange={(e) => setCoords({ ...coords, latitude: e.target.value })} placeholder="37.7749" className="h-11 w-full rounded-lg border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10" /><span className="block text-[10px] text-muted-foreground">−90 to 90</span></label><label className="space-y-1.5"><span className="text-xs font-semibold">Longitude</span><input data-testid="input-longitude" required type="number" step="any" min="-180" max="180" value={coords.longitude} onChange={(e) => setCoords({ ...coords, longitude: e.target.value })} placeholder="-122.4194" className="h-11 w-full rounded-lg border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10" /><span className="block text-[10px] text-muted-foreground">−180 to 180</span></label></div>
            <label className="block space-y-1.5"><span className="text-xs font-semibold">Date or year</span><input data-testid="input-date-year" required value={coords.dateOrYear} onChange={(e) => setCoords({ ...coords, dateOrYear: e.target.value })} placeholder="2024 or 2024-06-18" className="h-11 w-full rounded-lg border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10" /><span className="block text-[10px] text-muted-foreground">Past periods return historical observations. Future dates use forecasts where available.</span></label>
            <div className="rounded-lg bg-[#eef2e9] px-3.5 py-3 text-[11px] leading-relaxed text-[#556e63]"><div className="flex items-center gap-1.5 font-semibold"><Command size={12} />Accepted formats</div><p className="mt-1">Single day: <span className="mono">YYYY-MM-DD</span> · Whole year: <span className="mono">YYYY</span></p></div>
            {lookupError && <div role="alert" className="flex gap-2 rounded-lg border border-[#e7c3b7] bg-[#fbefeb] px-3 py-2.5 text-xs text-[#9a4935]"><XCircle size={15} className="mt-0.5 shrink-0" />{lookupError}</div>}
            <div className="flex justify-end gap-2 pt-1"><button type="button" onClick={() => setLookupOpen(false)} className="h-10 rounded-lg px-4 text-xs font-semibold text-muted-foreground hover:bg-muted">Cancel</button><button type="submit" disabled={createRequest.isPending} data-testid="button-submit-lookup" className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-xs font-bold text-primary-foreground disabled:opacity-65">{createRequest.isPending ? <><Loader2 size={14} className="animate-spin" />Querying weather</> : <><Send size={14} />Run lookup</>}</button></div>
          </form> : <div className="space-y-4">
            <div className="flex items-center gap-3 rounded-xl bg-[#e8f0eb] p-4"><div className="grid h-10 w-10 place-items-center rounded-full bg-[#d4e6dc] text-[#397756]"><CheckCircle2 size={20} /></div><div><div className="text-sm font-bold">Weather data returned</div><div className="mt-0.5 text-xs text-muted-foreground">{lookupResult.request.source} data · {lookupResult.readings.length} {lookupResult.readings.length === 1 ? 'reading' : 'readings'}</div></div><button onClick={() => setLookupResult(null)} className="ml-auto rounded-lg px-2 py-1 text-xs font-semibold text-primary hover:bg-white/60">New query</button></div>
            {lookupResult.periodNote && <div className="rounded-lg border border-[#e8d7b5] bg-[#fbf5e9] px-3.5 py-3 text-xs leading-relaxed text-[#795f3d]">{lookupResult.periodNote}</div>}
            <div className="rounded-xl border border-border bg-background px-4 py-3"><div className="flex items-center gap-2 text-xs font-semibold"><MapPin size={13} className="text-primary" /><span className="mono">{number(lookupResult.request.latitude, 4)}, {number(lookupResult.request.longitude, 4)}</span><span className="text-muted-foreground">·</span>{lookupResult.request.requestedDate}</div><div className="mt-1 text-[10px] text-muted-foreground">Request #{lookupResult.request.id} · {lookupResult.request.responseMs} ms</div></div>
            <div className="max-h-[420px] space-y-3 overflow-y-auto">{lookupResult.readings.length ? lookupResult.readings.map((reading) => <article key={reading.date} className="rounded-xl border border-border bg-background p-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Date</div><div className="mt-1 text-xs font-semibold">{reading.date}</div></div>
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Average</div><div className="mt-1 flex items-center gap-1 text-sm font-bold"><Thermometer size={13} className="text-[#cf8f49]" />{number(reading.temperature)}°C</div></div>
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Minimum</div><div className="mt-1 text-sm font-bold text-[#47766f]">{number(reading.minTemperature)}°C</div></div>
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Maximum</div><div className="mt-1 text-sm font-bold text-[#b5723e]">{number(reading.maxTemperature)}°C</div></div>
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Humidity</div><div className="mt-1 text-sm font-bold">{number(reading.humidity, 0)}%</div></div>
                <div><div className="text-[9px] uppercase tracking-wider text-muted-foreground">Dew point</div><div className="mt-1 text-sm font-bold">{number(reading.dewPoint)}°C</div></div>
                <div className="col-span-2 border-t border-border pt-2 text-xs text-muted-foreground sm:col-span-3 lg:col-span-6">{reading.conditions || 'No condition description returned'}</div>
              </div>
              {reading.hours.length > 0 && <section className="mt-4 border-t border-border pt-3" aria-label={`Hourly forecast for ${reading.date}`}>
                <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.12em] text-muted-foreground"><Clock3 size={13} className="text-primary" />Hourly breakdown · local time</div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {reading.hours.map((hour) => <div key={`${reading.date}-${hour.time}`} className="rounded-lg border border-border/80 bg-[#f8f8f3] px-3 py-2.5" data-testid="hourly-forecast">
                    <div className="mono text-[11px] font-bold text-foreground">{hour.time}</div>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-[10px] sm:grid-cols-4">
                      <div><div className="text-muted-foreground">Temp</div><div className="mt-0.5 font-bold">{number(hour.temperature)}°C</div></div>
                      <div><div className="text-muted-foreground">Humidity</div><div className="mt-0.5 font-bold">{number(hour.humidity, 0)}%</div></div>
                      <div><div className="text-muted-foreground">Dew point</div><div className="mt-0.5 font-bold">{number(hour.dewPoint)}°C</div></div>
                      <div><div className="text-muted-foreground">Wind speed</div><div className="mt-0.5 font-bold">{number(hour.windSpeed, 1)} km/h</div></div>
                    </div>
                  </div>)}
                </div>
              </section>}
            </article>) : <div className="rounded-lg border border-dashed border-border p-6 text-center text-xs text-muted-foreground">The request succeeded, but no daily readings were returned for this period.</div>}</div>
            <button onClick={() => setLookupOpen(false)} className="h-10 w-full rounded-lg bg-primary text-xs font-bold text-primary-foreground hover:brightness-95">Done</button>
          </div>}
        </div>
      </section>
    </div>}
  </div>;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
